public class Driver {

    public static void main(String[] args) {

        final double MM_PER_INCH = 25.4;

        //mm is easier to write than millimeters, so shh

        double width = 8.5;
        double height = 11;

        System.out.println(width * MM_PER_INCH);
        System.out.println(height * MM_PER_INCH);

    }

}
