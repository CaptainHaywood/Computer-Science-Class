public class Driver {
    public static void main(String[] args){
        StringBuilder rev = new StringBuilder ("desserts");
        rev.reverse();
        System.out.println(rev);
    }
}