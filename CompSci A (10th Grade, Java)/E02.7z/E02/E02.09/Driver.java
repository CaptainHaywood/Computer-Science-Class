import java.awt.Color;


public class Driver {
    public static void main(String[] args){
        Color c1 = new Color(50,100,150);
        
        Color c2 = c1.brighter();
        
        System.out.println(71);
	System.out.println(142);
	System.out.println(214);
    }
}