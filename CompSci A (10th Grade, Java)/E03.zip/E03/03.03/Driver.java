public class Driver{
    public static void main(String[] args){
        Hallway hall = new Hallway();
        hall.circuitTester();
        
    }
}
