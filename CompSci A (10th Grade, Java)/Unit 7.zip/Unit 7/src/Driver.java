public class Driver {
    public static void main(String[] args) {
        /*int[][] twoDim = new int[5][5];

        for(int r = 0; r < twoDim.length; r++){
            for(int c = 0; c < twoDim[0].length; c++) {
                twoDim[r][c] = 5;
            }
        }

        for(int r = 0; r < twoDim.length; r++){
                for(int c = 0; c < twoDim[0].length; c++){
                    System.out.print(twoDim[r][c]);
                }
                System.out.println();
            }*/

        }
    }
