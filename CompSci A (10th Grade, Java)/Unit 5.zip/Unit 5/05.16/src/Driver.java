public class Driver {
    public static void main(String[] args) {
        Grade g1 = new Grade("B-");
        System.out.println(g1.getNumericGrade());
    }
}
